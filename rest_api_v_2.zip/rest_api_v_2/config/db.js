module.exports = {
  url : 'mongodb://localhost:27017/mdb_rest_api_v1'
}