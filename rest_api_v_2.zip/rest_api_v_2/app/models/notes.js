// ../models/note.js
//-------------------------------------------------
const db 			= require('../modules/db/db').get()
const ObjectID   	= require('mongodb').ObjectID
//------------------------------------------------- R E A D   A L L
exports.findAll = function (callback) {
	db.collection('notes').find({}).toArray(function(err, items) {
		callback(err, items)
	  });
}
//------------------------------------------------- C R E A T E
exports.createEntrie = function (note, callback) {
    db.collection('notes').insert(note, (err, item) => {
    	callback(err, item)
    });
}
//------------------------------------------------- R E A D   B Y   _ID
exports.findById = function (id, callback) {
    db.collection('notes').findOne({ _id: ObjectID(id)}, (err, item) => {
    	callback(err, item)
    });
}
//------------------------------------------------- U P D A T E
exports.updateEntrie = function (id, newData, callback) {
    db.collection('notes').update({ _id: ObjectID(id) }, newData, (err, item) => {
    	callback(err, item, newData)
    });
}
//------------------------------------------------- D E L E T E
exports.deleteEntrie = function (id, callback) {
    db.collection('notes').remove({ '_id': ObjectID(id) }, (err, item) => {
    	callback(err, item)
    });
}