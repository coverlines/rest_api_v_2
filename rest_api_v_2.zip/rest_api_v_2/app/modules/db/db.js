// ../modules/db/db.js
//-------------------------------------------------
const MongoClient 		= require('mongodb').MongoClient
//-------------------------------------------------
const state = {
	db: null
}
//-------------------------------------------------
exports.connect = function (url, callback) {

	if (state.db !== null) return callback()

	MongoClient.connect(url, function (err, db) {
		if (err) return callback(err)
		state.db = db
		callback()
	})
}
//-------------------------------------------------
exports.get = function () {return state.db /* Database will returned */}