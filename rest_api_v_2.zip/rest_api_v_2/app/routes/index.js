// routes/index.js
//-------------------------------------------------
const noteRoutes 	= require('./routes');

module.exports = function(app) {
  noteRoutes(app);
  // ... THINK ABOUT MORE ROUTES ...
};