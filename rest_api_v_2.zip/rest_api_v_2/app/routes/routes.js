// ../routes/note_routes.js
//-------------------------------------------------
const notesController   = require('../controllers/notes')
//-------------------------------------------------
//-------------------------------------------------
module.exports = function(app) {
//------------------------------------------------- R E A D   A L L
  app.get('/notes', notesController.allEntries)
//------------------------------------------------- C R E A T E
  app.post('/notes', notesController.createEntrie)
//------------------------------------------------- R E A D   B Y   _ID
  app.get('/notes/:id', notesController.EntrieById)
//------------------------------------------------- U P D A T E
  app.put ('/notes/:id', notesController.EntrieUpdateById)
//------------------------------------------------- D E L E T E
  app.delete('/notes/:id', notesController.EntrieDeleteById)
//-------------------------------------------------
//-------------------------------------------------
};