// ../controllers/note.js
//-------------------------------------------------
const Notes 		= require ('../models/notes.js')
//------------------------------------------------- E R R O R --- 5 0 0
function err500(err) {
	if (err) {
		console.log(err)
		return res.sendStatus(500) // Server problems...
		// return res.send('ERROR')
  	}
}
//------------------------------------------------- R E A D   A L L
exports.allEntries = function (req,res) {
	Notes.findAll(function (err,items) {
		err500(err) // by error ---> returns res.sendStatus(500)
        res.send(items)
	})
}
//------------------------------------------------- C R E A T E
exports.createEntrie = function (req,res) {

	const note = { text: req.body.body, title: req.body.title }
	//-----------------------------
	Notes.createEntrie (note, function (err, item) {
		err500(err) 
        res.send(item.ops[0])
	})
}
//------------------------------------------------- R E A D   B Y   _ID
exports.EntrieById = function (req,res) {
	Notes.findById(req.params.id, function (err, item) {
		err500(err)
		res.send(item)
	})
}
//------------------------------------------------- U P D A T E
exports.EntrieUpdateById = function (req,res) {

    const note = { text: req.body.body, title: req.body.title }
    //-----------------------------
	Notes.updateEntrie(req.params.id, note, function (err, item, changedData) {
		err500(err)
		res.send(changedData)
	})
}
//------------------------------------------------- D E L E T E
exports.EntrieDeleteById = function (req,res) {

	Notes.deleteEntrie(req.params.id, function (err, item) {
		err500(err)
		res.send("Entrie by '_ID': " + req.params.id + " is deleted! " + item)
	})
}