// server.js - to run nodemon just --> npm run dev
//-------------------------------------------------
const express        = require('express')
const bodyParser     = require('body-parser')
const app            = express()
//------------------------------------------------- H O S T
const port = 8000;
//------------------------------------------------- D B
const db_url = require('./config/db')
const db = require('./app/modules/db/db')
// //---------------------------------------------- E N D C O D I N G
app.use(bodyParser.urlencoded({ extended: true }))
//------------------------------------------------- D B - C O N N E C T
db.connect(db_url.url, (err) => {
  if (err) {
  	return console.log(err)
  }
  require('./app/routes')(app)
//------------------------------------------------- LISTEN
 	app.listen(port, () => {
    console.log('We are on Port: ' + port)
  })       
})